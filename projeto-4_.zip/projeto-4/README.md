# Algoritmos e Pensamento Computacional

Exercícios em C feitos nas aulas da disciplina de Algoritmos e Pensamento Computacional.

## Estrutura

```
projeto-4/
├── README.md
├── .gitignore
└── aulas/
    ├── aula_03.c
    ├── ...
    ├── aula_10.c
    └── tabuada.txt   (arquivo lido pela aula 9)
```

## Como compilar e executar

Dentro da pasta `aulas`:

```
gcc aula_03.c -o aula_03
./aula_03
```

No Windows, execute com `aula_03.exe`.

A **aula 4** usa a biblioteca de matemática (`math.h`), então precisa do `-lm`:

```
gcc aula_04.c -o aula_04 -lm
```

A **aula 9** lê o arquivo `tabuada.txt`, por isso deve ser executada dentro da pasta `aulas`.

## Aulas

| Arquivo | Conteúdo |
|---|---|
| `aula_03.c` | Perímetro da circunferência a partir do raio |
| `aula_04.c` | Quantidade de caixas de revestimento e custo total (área, `ceil`) |
| `aula_05.c` | Valor da hospedagem por tipo de quarto e diárias (`switch`) |
| `aula_06.c` | Tabuada de um número (laço `for`) |
| `aula_07.c` | Média da turma com validação das notas de 0 a 10 (`for` e `while`) |
| `aula_08.c` | Matriz de vendas 3x4: leitura e exibição |
| `aula_09.c` | Leitura de arquivo texto, linha por linha |
| `aula_10.c` | Ordenação de um vetor de senhas com Bubble Sort (funções e vetores) |
