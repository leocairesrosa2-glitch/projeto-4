/*
 * Nome: LEONARDO CAIRES ROSA
 * RGM : 48123676
 *
 * Aula 9 - Leitura de arquivo texto
 *
 * Abre o arquivo "tabuada.txt" e mostra o conteúdo na tela, linha por linha.
 * O arquivo precisa estar na mesma pasta de onde o programa é executado.
 */
#include <stdio.h>

int main(void) {
    FILE *arquivo;
    char linha[100];

    arquivo = fopen("tabuada.txt", "r");

    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo tabuada.txt!\n");
        printf("Verifique se ele está na mesma pasta do programa.\n");
        return 1;
    }

    while (fgets(linha, sizeof(linha), arquivo) != NULL) {
        printf("%s", linha);
    }

    fclose(arquivo);

    return 0;
}
