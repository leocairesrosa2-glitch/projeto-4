/*
 * Nome: LEONARDO CAIRES ROSA
 * RGM : 48123676
 *
 * Aula 4 - Revestimento de uma área
 *
 * Lê a largura e o comprimento de uma área (em metros) e o valor de cada
 * caixa de revestimento. Calcula a área total, a quantidade de caixas
 * necessárias (sempre um número inteiro) e o custo total da compra.
 *
 * Para compilar, é preciso ligar a biblioteca de matemática:
 *     gcc aula_04.c -o aula_04 -lm
 */
#include <stdio.h>
#include <math.h>

#define AREA_POR_CAIXA 2.5   /* cada caixa cobre 2,5 m² */

int main(void) {
    float largura = 0, comprimento = 0, valorCaixa = 0;
    float area, quantidadeCaixas, custoTotal;

    printf("Qual e a largura da area (em metros)? ");
    scanf("%f", &largura);

    printf("Qual e o comprimento da area (em metros)? ");
    scanf("%f", &comprimento);

    printf("Qual e o valor de cada caixa? ");
    scanf("%f", &valorCaixa);

    if (largura <= 0 || comprimento <= 0 || valorCaixa < 0) {
        printf("Valores invalidos!\n");
        return 1;
    }

    /* Calcula a área total */
    area = largura * comprimento;

    /* ceil() arredonda para cima, garantindo caixas inteiras */
    quantidadeCaixas = ceil(area / AREA_POR_CAIXA);

    /* Calcula o custo total */
    custoTotal = quantidadeCaixas * valorCaixa;

    printf("\nArea total a ser revestida: %.2f m^2\n", area);
    printf("Quantidade de caixas necessarias: %.0f\n", quantidadeCaixas);
    printf("Custo total da compra: R$ %.2f\n", custoTotal);

    return 0;
}
