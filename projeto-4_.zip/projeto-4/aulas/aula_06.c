/*
 * Nome: LEONARDO CAIRES ROSA
 * RGM : 48123676
 *
 * Aula 6 - Tabuada (laço for)
 *
 * Lê um número e mostra a tabuada dele de 1 a 10.
 */
#include <stdio.h>

int main(void) {
    int numero = 0;
    int i;

    printf("Digite um numero: ");
    scanf("%d", &numero);

    for (i = 1; i <= 10; i++) {
        printf("%d x %d = %d\n", numero, i, numero * i);
    }

    return 0;
}
