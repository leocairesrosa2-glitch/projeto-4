/*
 * Nome: LEONARDO CAIRES ROSA
 * RGM : 48123676
 *
 * Aula 8 - Matriz de vendas
 *
 * Lê os valores de vendas em uma matriz de 3 linhas por 4 colunas
 * e depois mostra todos os valores digitados.
 */
#include <stdio.h>

#define LINHAS  3
#define COLUNAS 4

int main(void) {
    int vendas[LINHAS][COLUNAS];
    int i, j;

    /* leitura dos valores */
    for (i = 0; i < LINHAS; i++) {
        for (j = 0; j < COLUNAS; j++) {
            printf("Digite o valor da venda [%d][%d]: ", i, j);
            scanf("%d", &vendas[i][j]);
        }
    }

    printf("\n");

    /* exibição dos valores */
    for (i = 0; i < LINHAS; i++) {
        for (j = 0; j < COLUNAS; j++) {
            printf("O valor da venda [%d][%d] é: %d\n", i, j, vendas[i][j]);
        }
    }

    return 0;
}
