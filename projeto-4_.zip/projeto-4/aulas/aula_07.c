/*
 * Nome: LEONARDO CAIRES ROSA
 * RGM : 48123676
 *
 * Aula 7 - Média da turma (laços for e while)
 *
 * Lê a quantidade de alunos e a nota de cada um. Se a nota estiver fora
 * do intervalo de 0 a 10, pede para digitar novamente. No final, mostra
 * a média da turma.
 */
#include <stdio.h>

int main(void) {
    int quantidade = 0;
    int i;
    float nota = 0;
    float soma = 0;
    float media;

    printf("Quantidade de alunos: ");
    scanf("%d", &quantidade);

    /* evita divisão por zero no cálculo da média */
    if (quantidade <= 0) {
        printf("Quantidade invalida!\n");
        return 1;
    }

    for (i = 1; i <= quantidade; i++) {
        printf("Nota %d: ", i);
        scanf("%f", &nota);

        /* validação: repete enquanto a nota for inválida */
        while (nota < 0 || nota > 10) {
            printf("Nota invalida!\n");
            printf("Digite novamente: ");
            scanf("%f", &nota);
        }

        soma = soma + nota;
    }

    media = soma / quantidade;

    printf("\nMedia da turma: %.2f\n", media);

    return 0;
}
